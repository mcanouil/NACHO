## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(knitr)
knitr::opts_chunk$set(
  eval = FALSE,
  results = "asis",
  include = TRUE,
  echo = TRUE,
  warning = FALSE,
  message = FALSE,
  tidy = FALSE,
  crop = TRUE,
  autodep = TRUE,
  fig.align = 'center',
  fig.pos = '!h',
  cache = FALSE
)

## ----logo----------------------------------------------------------------
#  knitr::include_graphics(system.file("shiny", "www", "Nacho_logo.png", package = "NACHO"))

## ----pressure, eval = TRUE-----------------------------------------------
library(NACHO)
data(GSE74821)
my_nacho <- GSE74821

## ------------------------------------------------------------------------
#  visualise(my_nacho)

## ----screen, fig.cap = "Screenshot of **NACHO**"-------------------------
#  include_graphics("nacho_screen.png")

## ----ex2-----------------------------------------------------------------
#  library(GEOquery)
#  gse <- getGEO(gse = "GSE74821")
#  targets <- pData(phenoData(gse[[1]]))
#  
#  getGEOSuppFiles(targets = "GSE74821")
#  untar(tarfile = "GSE74821/GSE74821_RAW.tar", exdir = "example/Data")
#  
#  targets$IDFILE <- list.files(path = "example/Data", pattern = ".RCC.gz$")
#  
#  write.csv(x = targets, file= "example/Samplesheet.csv")

## ----ex3-----------------------------------------------------------------
#  library(NACHO)
#  my_nacho <- summarise(
#    data_directory = "example/Data",
#    ssheet_csv = "example/Samplesheet.csv",
#    id_colname = "IDFILE",
#    housekeeping_genes = NULL,
#    housekeeping_predict = FALSE,
#    housekeeping_norm = TRUE,
#    normalisation_method = "GLM",
#    n_comp = 10
#  )
#  visualise(my_nacho)

## ----ex4-----------------------------------------------------------------
#  library(NACHO)
#  my_nacho <- summarise(
#    data_directory = "example/Data",
#    ssheet_csv = "example/Samplesheet.csv",
#    id_colname = "IDFILE",
#    housekeeping_genes = NULL,
#    housekeeping_predict = TRUE,
#    housekeeping_norm = TRUE,
#    normalisation_method = "GLM",
#    n_comp = 10
#  )
#  my_nacho

## ----ex5-----------------------------------------------------------------
#  print(my_nacho["housekeeping_genes"])

## ----ex6-----------------------------------------------------------------
#  my_housekeeping <- my_nacho["housekeeping_genes"][-c(1, 2)]
#  print(my_housekeeping)

## ----ex7-----------------------------------------------------------------
#  my_nacho_improved <- normalise(
#    nacho_object = my_nacho,
#    housekeeping_genes = my_housekeeping,
#    housekeeping_norm = TRUE,
#    normalisation_method = "GLM",
#    remove_outliers = TRUE
#  )

## ----ex8-----------------------------------------------------------------
#  my_nacho_improved

## ----session-------------------------------------------------------------
#  devtools::session_info()

