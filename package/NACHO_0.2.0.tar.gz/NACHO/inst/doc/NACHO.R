## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(knitr)
knitr::opts_chunk$set(
  eval = FALSE,
  results = "asis",
  include = TRUE,
  echo = TRUE,
  warning = FALSE,
  message = FALSE,
  tidy = FALSE,
  crop = TRUE,
  autodep = TRUE,
  fig.align = 'center',
  fig.pos = '!h',
  cache = FALSE
)

## ----logo----------------------------------------------------------------
#  knitr::include_graphics(system.file("shiny", "www", "Nacho_logo.png", package = "NACHO"))

## ----pressure------------------------------------------------------------
#  library(nacho)
#  data(exampleData)
#  visualise(exampleData)

## ----screen, fig.cap = "Screenshot of **NACHO**"-------------------------
#  include_graphics("nacho_screen.png")

## ----ex2-----------------------------------------------------------------
#  library(GEOquery)
#  gse <- getGEO(gse = "GSE74821")
#  targets <- pData(phenoData(gse[[1]]))
#  
#  getGEOSuppFiles(targets = "GSE74821")
#  untar(tarfile = "GSE74821/GSE74821_RAW.tar", exdir = "example/Data")
#  
#  targets$IDFILE <- list.files(path = "example/Data", pattern = ".RCC.gz$")
#  
#  write.csv(x = targets, file= "example/Samplesheet.csv")

## ----ex3-----------------------------------------------------------------
#  library(NACHO)
#  my_nacho <- summarise(
#    data_directory = "example/Data",
#    ssheet_csv = "example/Samplesheet.csv",
#    id_colname = "IDFILE",
#    housekeeping_genes = NULL,
#    predict_housekeeping = FALSE,
#    normalisation_method = "GLM",
#    n_comp = 10
#  )
#  visualise(my_nacho)

## ----ex4-----------------------------------------------------------------
#  library(NACHO)
#  my_nacho <- summarise(
#    data_directory = "example/Data",
#    ssheet_csv = "example/Samplesheet.csv",
#    id_colname = "IDFILE",
#    housekeeping_genes = NULL,
#    predict_housekeeping = TRUE,
#    normalisation_method = "GLM",
#    n_comp = 10
#  )

## ----ex5-----------------------------------------------------------------
#  print(my_nacho["housekeeping_genes"])

## ----ex6-----------------------------------------------------------------
#  my_housekeeping <- my_nacho["housekeeping_genes"][c(1, 2)]
#  print(my_housekeeping)

## ----ex7-----------------------------------------------------------------
#  my_nacho_improved <- normalise(
#    nacho_object = my_nacho,
#    housekeeping_genes = my_housekeeping,
#    normalisation_method = "GLM",
#    remove_outliers = TRUE
#  )

## ----ex8-----------------------------------------------------------------
#  my_data$scaling #Table 1
#  my_data$counts #Table 2
#  my_data$normalised #Table 3

## ----ex9-----------------------------------------------------------------
#  table_data1 <- as.matrix(my_data$scaling[1:5, ])
#  colnames(table_data1) <- c("Positive Factor", "Background Signal", "Housekeeping Factor")
#  rownames(table_data1) <- c("GSM1934697", "GSM1934698", "GSM1934699", "GSM1934700", "GSM1934701")
#  stargazer::stargazer(table_data1, type = "html", title = "Normalisation values", header = FALSE)

## ----ex10----------------------------------------------------------------
#  table_data2 <- my_data$counts[1:5, 1:5]
#  colnames(table_data2) <- c("GSM1934697", "GSM1934698", "GSM1934699", "GSM1934700", "GSM1934701")
#  stargazer::stargazer(table_data2, type = "html", title = "Raw counts", header = FALSE)

## ----ex11----------------------------------------------------------------
#  table_data3 <- as.matrix(my_data$normalised[1:5, 1:5])
#  colnames(table_data3) <- c("GSM1934697", "GSM1934698", "GSM1934699", "GSM1934700", "GSM1934701")
#  stargazer::stargazer(table_data3, type = "html", title = "Transformed counts", header = FALSE)

## ----session-------------------------------------------------------------
#  devtools::session_info()

