#' Presummarized example data.
#'
#' A dataset containing sample specific attributes and .
#'
#' @format A list containing 11 items
#' @source \url{https://www.ncbi.nlm.nih.gov/geo/}
"exampleData"