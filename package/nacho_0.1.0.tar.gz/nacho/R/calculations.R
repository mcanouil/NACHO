#' @title Imaging QC
#' @description Calculates percentage succesfully counted image sections.
#' @param fov.counted succesfully counted image sections.
#' @param fov.count attempted counted image sections.
#' @return Percentage succesfully counted image sections.
#' @keywords internal
imaging.qc <- function(fov.counted, fov.count){
  fov = (fov.counted / fov.count) * 100
  return(round(fov,2))
}

#' @title Positive Control Linearity QC
#' @description  Calculates pearsons correlation coefficient of 
#' positive control gene expression versus concentrations.
#' @param pos.counts Vector of measured positive control gene expression.
#' @return Correlation coefficient
#' @keywords internal
positive.control.qc <- function(pos.counts){
  known <- log2(c(128,32,8,2,0.5))
  measured <- log2(pos.counts[1:5])
  correlation <- cor.test(known, measured)
  return(unname(round(correlation$estimate,5)))
}

#' @title Limit of Detection QC
#' @description Calculates distance of POS_E expression from mean of
#'  negative control gene expressoins in term of standard deviations.
#' @param pos.e Expression of positive control gene "POS_E"
#' @param negatives Vector of negative control gene expressoins.
#' @return z-score
#' @keywords internal
limit.detection.qc <- function(pos.e, negatives){
  z_score <- pos.e - mean(negatives) / sd(negatives)
  return(round(z_score,2))
}

#' @title Prinicipal components
#' @description Calculates and returns principal components of a given
#' dataframe.
#' @param counts dataframe of nanoString counts
#' @return list containing a dataframe the first 10 principal components
#' and summary
#' @keywords internal
prinicipal_components <- function(counts){
  pc <- prcomp(log(counts+1))
  pc_sum <- summary(pc)
  pc <- pc$rotation[,1:10]
  output <- list("pc" = pc,
                 "pcsum" = pc_sum$importance[,1:10])
  return(output)
}

#' @title Geometric mean
#' @description Calculates and returns geometric mean of a given vector.
#' @param vector_data numeric vector
#' @return geometric mean
#' @keywords internal
geoMean <- function(vector_data){
  vector_data[vector_data == 0] <- 1
  exp(mean(log(vector_data)))
}

#' @title Extracts counts of control probes and calculates the geometric mean.
#' @description Extracts counts of control probes and calculates the
#' geometric mean. Excludes positive control probe F in calculation.
#' @param rcc_content List of dataframes originating from RCC files
#' @param probes String of either "Positve" or "Negative"
#' @return geometric mean of control probes
#' @keywords internal
geometric <- function(rcc_content, probes,ex_negs=NULL){
  counts <- rcc_content$Code_Summary
  if(probes == "Positive"){
    control_data <- as.numeric(counts[counts$CodeClass %in%
                                        probes & counts$Name !=
                                        "POS_F(0.125)","Count"])
    control_data[control_data == 0] <- 1 
  }else if(probes == "Negative"){
    probes_out <- ex_negs
    control_data <- counts[!counts$Name %in% probes_out,]
    control_data <- as.numeric(counts[counts$CodeClass %in%
                                        probes,"Count"])
    control_data[control_data == 0] <- 1
    
  }
  return(geoMean(control_data))
}

#' @title Calculates the background threshold and positive normalization 
#' factor by means of generalized linear models.
#' @description Calculates the background threshold and positive normalization 
#' factor by means of generalized linear models. Uses the intercept of the model
#' as background threshold and the slope as positive normalization factor,
#' excludes positive control probe F.
#' @param rcc_content List of dataframes originating from RCC files
#' @return Vector with positive factor and backrground threshold
#' @keywords internal
intercept_slope <- function(rcc_content,exc_negs){
  probes_out <- c("POS_F(0.125)",exc_negs)
  counts <- rcc_content$Code_Summary
  control_labels <- c("Positive","Negative")
  control_data <- counts[counts$CodeClass %in% control_labels,]
  control_data <- control_data[order(control_data$Name),]
  control_data <- control_data[!control_data$Name %in% probes_out,]
  prob_names <- paste0(control_data$Name,collapse = "")
  y <- as.numeric(control_data$Count) + 1
  x <- as.numeric(gsub("[\\(\\)]", "", regmatches(prob_names,
                                                  gregexpr("\\(.*?\\)", prob_names))[[1]]))
  model <- glm(y~x, family = poisson(link = identity))
  output <- c("intercept" = unname(model$coeff[1]),
              "slope" = unname(model$coeff[2]))
  return(output)
}

#' @title Factor Calculation
#' @description Calculates normalization factors
#' @param rcc_content List of dataframes originating from RCC files
#' @param housekeep String of names of housekeeping genes
#' @param norm A string indicating which form of calculation needs to be performed
#' @return Dataframe of normalization factor for each sample
#' @keywords internal
factor_calculation <- function(rcc_content, housekeep, norm, ex_negs){
  if(norm == "GEO"){
    geometric_mean_pos <- sapply(rcc_content, geometric, "Positive")
    geometric_mean_neg <- sapply(rcc_content, geometric, "Negative",ex_negs)
    positive_factor <- sapply(geometric_mean_pos,
                              function(x) mean(geometric_mean_pos) / x)
  }else if(norm == "GLM"){
    glms <- sapply(rcc_content, intercept_slope, ex_negs)
    geometric_mean_neg <- glms["intercept",]
    slopes <- glms["slope",]
    positive_factor <- sapply(slopes,
                              function(x) mean(slopes) / x)
  }
  if(housekeep == "predict"){
    norm_factor <- data.frame("Positive_factor" = positive_factor,
                              "Negative_factor" = geometric_mean_neg)
  }else{
    housecounts <- mapply(housekeeping,rcc_content, positive_factor,
                          geometric_mean_neg, housekeep)
    housecounts <- as.data.frame(housecounts)
    geometric_mean_house <- sapply(housecounts,
                                   function(x) geoMean(x))
    house_factor <- sapply(geometric_mean_house,
                           function(x) mean(geometric_mean_house) / x)
    house_factor <- unname(house_factor)
    norm_factor <- data.frame("Positive_factor" = positive_factor,
                              "Negative_factor" = geometric_mean_neg,
                              "House_factor" = house_factor)
  }
  return(norm_factor)
}

#' @title Predict housekeeping genes
#' @description Predicts which genes could serve as housekeeping genes
#' @param counts dataframe of nanoString counts
#' @return vector of 5 possible housekeeping genes
#' @keywords internal
predict.housekeeping <- function(counts){
  sample_means <- sapply(colnames(counts), function(x) mean(counts[,x]))
  ratios <- sapply(colnames(counts), function(x) log2(counts[,x] / sample_means[x]))
  ratios <- ratios[sum(is.infinite(ratios)) / length(ratios) <= 0.05,]
  ratios <- ifelse(is.infinite(ratios),NA,ratios)
  miR_sd <- sapply(rownames(ratios), function(x) sd(ratios[x,],na.rm = TRUE))
  miR_sd <- sort(miR_sd, decreasing = F)
  return(names(miR_sd)[1:5])
}

#' @title Probe exclusion
#' @description Compares probe specfic median with overal median, excludes probes when
#' probe specific mean differs more than 50% from overal median
#' @param control_genes dataframe of all control genes
#' @return names of excluded probes
#' @keywords internal
probe.exclusion <- function(control_genes){
  local_neg <- control_genes[control_genes$CodeClass == "Negative",]
  dcasted<- dcast(L1~Name, data = local_neg[,c("Name","L1","Count")], value.var = "Count")
  rownames(dcasted) <- dcasted$L1
  dcasted$L1 <- NULL
  overal_median <- median(as.numeric(local_neg$Count))
  medians <- sapply(dcasted,function(x) median(as.numeric(x)))
  delta_medians <- sapply(medians,function(x) abs((overal_median-x)))
  ex_probes <- delta_medians[delta_medians > (0.5*overal_median)]
  return(names(ex_probes))
}